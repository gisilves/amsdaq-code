#!/bin/bash
./TakePCI 0 $@
